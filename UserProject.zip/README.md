# Flask Web Application

This is a simple web application built using Python Flask.

## File Structure

- `main.py`: The main application file.
- `templates/`: Directory containing HTML templates.
  - `index.html`: The main HTML page.

## How to Run

1. Ensure you have Flask installed.
2. Run the application using `python main.py`.
3. Open your browser and navigate to `http://127.0.0.1:5000/`.
