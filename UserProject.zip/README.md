# User Info Flask App

This is a simple Flask application that allows users to input their information and stores it locally in a JSON file.

## Project Structure

