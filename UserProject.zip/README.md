# Flask Hello World Application

This is a simple Flask application that displays "Hello, World!" in the browser.

## Project Structure

